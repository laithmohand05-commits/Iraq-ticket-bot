require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  ChannelType,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

const CATEGORY_NAME = "🎫 التذاكر";
const STAFF_ROLE_ID = ""; // اختياري: حط ID رتبة الإدارة هنا

client.once("ready", () => {
  console.log(`✅ البوت شغال: ${client.user.tag}`);
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === "open_ticket") {
    const existing = interaction.guild.channels.cache.find(
      c => c.type === ChannelType.GuildText &&
           c.name === `تكت-${interaction.user.username.toLowerCase()}`
    );

    if (existing) {
      return interaction.reply({
        content: `⚠️ عندك تكت مفتوح بالفعل: ${existing}`,
        ephemeral: true
      });
    }

    let category = interaction.guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && c.name === CATEGORY_NAME
    );

    if (!category) {
      category = await interaction.guild.channels.create({
        name: CATEGORY_NAME,
        type: ChannelType.GuildCategory
      });
    }

    const overwrites = [
      {
        id: interaction.guild.roles.everyone.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      },
      {
        id: interaction.user.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory
        ]
      },
      {
        id: interaction.client.user.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ManageChannels,
          PermissionsBitField.Flags.ReadMessageHistory
        ]
      }
    ];

    if (STAFF_ROLE_ID) {
      overwrites.push({
        id: STAFF_ROLE_ID,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory
        ]
      });
    }

    const channel = await interaction.guild.channels.create({
      name: `تكت-${interaction.user.username}`,
      type: ChannelType.GuildText,
      parent: category.id,
      permissionOverwrites: overwrites
    });

    const embed = new EmbedBuilder()
      .setTitle("🎫 تكت الدعم")
      .setDescription(
        `هلا ${interaction.user} 👋\n\n` +
        "اكتب طلبك هنا، وانتظر رد الإدارة.\n" +
        "لإغلاق التكت اضغط الزر بالأسفل."
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("close_ticket")
        .setLabel("🔒 إغلاق التكت")
        .setStyle(ButtonStyle.Danger)
    );

    await channel.send({ embeds: [embed], components: [row] });

    await interaction.reply({
      content: `✅ تم فتح التكت: ${channel}`,
      ephemeral: true
    });
  }

  if (interaction.customId === "close_ticket") {
    await interaction.reply("🔒 سيتم حذف التكت خلال 5 ثواني...");
    setTimeout(() => {
      interaction.channel.delete().catch(() => {});
    }, 5000);
  }
});

client.on("ready", async () => {
  for (const guild of client.guilds.cache.values()) {
    const existing = guild.channels.cache.find(
      c => c.type === ChannelType.GuildText && c.name === "🎫・فتح-تكت"
    );

    if (!existing) {
      const channel = await guild.channels.create({
        name: "🎫・فتح-تكت",
        type: ChannelType.GuildText
      });

      const embed = new EmbedBuilder()
        .setTitle("🎫 فتح تكت")
        .setDescription("اضغط الزر بالأسفل لفتح تكت خاص مع الإدارة.");

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("open_ticket")
          .setLabel("🎫 فتح تكت")
          .setStyle(ButtonStyle.Primary)
      );

      await channel.send({ embeds: [embed], components: [row] });
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
